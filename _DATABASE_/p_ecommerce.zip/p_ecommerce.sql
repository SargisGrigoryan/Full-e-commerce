-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 04, 2021 at 03:10 PM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `p_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `first_name`, `last_name`, `email`, `password`, `status`) VALUES
(1, 'Sargis', 'Grigoryan', 'sargis.web@gmail.com', '$2y$10$IBABeEyoy0S.k4FJ6BfmG.1Vxx1ychVL0xa1tyTzatLOodzl692ni', '1');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `color` varchar(50) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `qty`, `color`, `status`) VALUES
(41, 4, 14, 1, 'Black', '1'),
(40, 4, 20, 1, 'Black', '1');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cat_name`, `date`) VALUES
(1, 'Mobile', '2020-12-31 19:44:54'),
(22, 'Smart watch', '2021-01-04 14:04:54'),
(21, 'TV', '2021-01-02 03:56:31');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `product_id` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('0','1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `admin_id`, `comment`, `product_id`, `date`, `status`) VALUES
(3, 4, 0, 'Hi it\'s me)', 15, '2020-12-17 17:22:34', '1'),
(2, 5, 0, 'This is other user\'s comment', 15, '2020-12-17 17:22:34', '1'),
(4, 4, 0, 'Again me))', 15, '2020-12-17 17:22:34', '1'),
(5, 5, 0, 'Wow awesome !!!', 15, '2020-12-18 16:57:21', '1'),
(6, 5, 0, ':)', 15, '2020-12-18 16:58:13', '1'),
(7, 4, 0, 'Yep ;)', 15, '2020-12-18 17:07:13', '1'),
(8, 4, 0, 'I already ordered this product, and now I\'m waiting for that.', 15, '2020-12-18 17:13:54', '1'),
(9, 6, 0, 'I think they updated it\'s design :)', 15, '2020-12-18 17:29:31', '1'),
(10, 4, 0, 'aaa', 14, '2020-12-20 16:06:37', '1'),
(11, 4, 0, 'bbb', 14, '2020-12-20 16:09:12', '1'),
(12, 4, 0, 'I\'m still waiting to the new one', 15, '2020-12-20 17:23:59', '1'),
(13, 4, 0, ')))', 15, '2020-12-20 17:25:39', '1'),
(14, 4, 0, '>>>', 15, '2020-12-20 17:28:36', '1'),
(15, 4, 0, 'aaa', 15, '2020-12-20 17:31:10', '1'),
(16, 5, 0, '111', 23, '2020-12-20 17:31:50', '1'),
(17, 4, 0, 'ggg', 23, '2020-12-20 17:32:36', '1'),
(18, 5, 0, 'asd', 15, '2020-12-20 17:36:52', '1'),
(19, 6, 0, 'ccc', 14, '2020-12-21 16:02:05', '1'),
(20, 6, 0, 'ccc', 14, '2020-12-21 16:02:11', '1'),
(21, 6, 0, 'ccc', 14, '2020-12-21 16:02:17', '1'),
(22, 6, 0, 'ccc', 14, '2020-12-21 16:02:21', '1'),
(23, 6, 0, '1', 9, '2020-12-21 16:02:58', '1'),
(24, 6, 0, '1', 9, '2020-12-21 16:03:00', '1'),
(25, 6, 0, '3', 9, '2020-12-21 16:03:06', '1'),
(26, 6, 0, '4', 9, '2020-12-21 16:03:08', '1'),
(27, 6, 0, '5', 9, '2020-12-21 16:03:11', '1'),
(28, 6, 0, '6', 9, '2020-12-21 16:04:13', '1'),
(29, 5, 0, 'bbb', 15, '2020-12-21 16:57:35', '1'),
(30, 0, 1, 'this is my first admin message', 15, '2020-12-21 17:24:07', '1'),
(31, 0, 1, '123', 15, '2020-12-21 17:34:02', '1'),
(32, 0, 1, '123', 15, '2020-12-21 17:34:08', '1'),
(33, 0, 1, 'AAAAAAAAAAAAAAA', 15, '2020-12-21 18:32:55', '1'),
(34, 4, 0, 'It\'s me ))', 15, '2020-12-21 18:53:06', '1'),
(35, 0, 1, 'Ji I\'m Admin', 15, '2020-12-21 19:00:57', '1'),
(36, 0, 1, 'hi I\'m Admin', 15, '2020-12-21 19:01:02', '1'),
(37, 0, 1, 'asd', 15, '2020-12-21 19:05:47', '1'),
(38, 4, 0, 'I try to do some comments for testing )))', 20, '2020-12-31 12:05:19', '1'),
(39, 4, 0, 'Test comment', 14, '2020-12-31 13:22:39', '1');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `src` text NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `src`, `product_id`) VALUES
(4, '/gallery/a377cab47887074a7cd2c88410c46e57.jpg', 21),
(3, '/gallery/a377cab47887074a7cd2c88410c46e57.png', 21),
(5, '/gallery/a377cab47887074a7cd2c88410c46e57.jpg', 21),
(6, '/gallery/fa9fce046612338bebf6f8b464361492.png', 22),
(7, '/gallery/96edfa6d51443fa25a6ff940b3e02555.jpg', 22),
(8, '/gallery/a343d2c61399decbece6ea73435cb7d2.jpg', 22),
(9, '/gallery/a956cc1a2182e0336f180ba0c64d24d0.png', 23),
(10, '/gallery/2eee7cfe71e3f46f0589695f24290e76.jpg', 23),
(12, '/gallery/3dc45ee1c1aaaf5088673f4f1e5bd462.png', 15),
(13, '/gallery/69feb0b06afba9c17b13812253a99a54.jpg', 15),
(14, '/gallery/6e86071d01d730aa85e653e837740f77.jpg', 15),
(15, '/gallery/00b29945aaa36ab7d7a6ce1e98c0fd43.jpg', 9),
(16, '/gallery/a280b7424f2a5664ea1e235418671112.jpg', 9),
(17, '/gallery/c122dca0de0443a18e6cb8bc3900cfd1.jpg', 9),
(18, '/gallery/9bc8aa0b22a2019621dc38b5ea52bcc6.jpg', 16),
(19, '/gallery/86cd4ce3c11091138fef7dd0f488fcea.jpg', 16),
(20, '/gallery/b430286ff138089cf19ad76fd0458cfc.jpg', 16),
(21, '/gallery/b0f3f5233c837e0d44a0e407b4552c6b.jpg', 24),
(22, '/gallery/489ca3f6d769b1333981eb9466cc3d88.jpg', 24),
(23, '/gallery/24481a63dacbaa2d367a4cb10e8ce5a8.jpg', 24),
(24, '/gallery/de04e09ea8cceb7822804d7bade90706.jpg', 25),
(25, '/gallery/6ab96e16ab1489dc99639f3e1e06597e.jpg', 25),
(26, '/gallery/e943b544a4ef11a8799dad996a0f9ebc.webp', 25),
(27, '/gallery/b3a7ad56c4288f3abadeb44563d9d73a.jpg', 20),
(28, '/gallery/f2413095ea1798aa9946b95b41ed1c45.jpg', 20),
(29, '/gallery/4e0869c673a2a0c0594262d18bfabae9.webp', 20);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `cvv` varchar(100) NOT NULL,
  `products_qty` int(11) NOT NULL,
  `products_price` int(11) NOT NULL,
  `delivery_price` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('0','1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `first_name`, `last_name`, `cvv`, `products_qty`, `products_price`, `delivery_price`, `user_id`, `date`, `status`) VALUES
(1, 'Sargis', 'Grigoryan', '1234', 10, 2219, 15, 4, '2020-12-17 14:40:52', '0'),
(2, 'Sargis', 'Grigoryan', '1234-****-****-****', 10, 2219, 15, 4, '2020-12-17 14:46:41', '1'),
(3, 'Sargis', 'Grigoryan', '1234-****-****-****', 10, 2219, 15, 4, '2020-12-17 14:50:44', '2'),
(4, 'Sargis', 'Grigoryan', '1234-****-****-****', 8, 1840, 15, 4, '2020-12-17 14:53:37', '1'),
(5, 'My First Name', 'My Last Name', '1234-****-****-****', 8, 2129, 15, 4, '2020-12-17 15:11:07', '1'),
(6, 'Test', 'Test', '1234-****-****-****', 2, 375, 15, 4, '2020-12-17 15:15:23', '1'),
(7, 'Sargis', 'Grigoryan', '1234-****-****-****', 1, 230, 15, 4, '2020-12-17 16:37:32', '1'),
(8, 'Test_disc', 'Test_disc', '1234-****-****-****', 4, 0, 15, 4, '2020-12-17 16:43:38', '1'),
(9, 'Test_disc', 'Test_disc', '1234-****-****-****', 4, 600, 15, 4, '2020-12-17 16:44:46', '1'),
(10, 'Test_disc', 'Test_disc', '1234-****-****-****', 4, 600, 10, 4, '2020-12-17 16:45:08', '1');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `descr` text NOT NULL,
  `image` text NOT NULL,
  `cat_id` int(11) NOT NULL,
  `colors` text NOT NULL,
  `display` text NOT NULL,
  `camera` text NOT NULL,
  `memory` text NOT NULL,
  `ram` text NOT NULL,
  `slider` enum('0','1') NOT NULL DEFAULT '0',
  `slider_image` text,
  `price` varchar(50) NOT NULL,
  `discount` varchar(50) NOT NULL DEFAULT '0',
  `top` enum('0','1') NOT NULL DEFAULT '0',
  `in_stock` int(11) NOT NULL DEFAULT '0',
  `status` enum('0','1','2') NOT NULL DEFAULT '1',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `descr`, `image`, `cat_id`, `colors`, `display`, `camera`, `memory`, `ram`, `slider`, `slider_image`, `price`, `discount`, `top`, `in_stock`, `status`, `date`) VALUES
(13, 'Samsung', 'Some descr....', '/images/e713908357271053ae3ae31967b4786b.jpg', 1, 'Black, White', 'LCD', '8K', '128GB', '4GB', '0', NULL, '200', '25', '1', 5, '1', '2020-12-07 13:56:18'),
(14, 'Huawei honor', 'Some descr for huawei and ...', '/images/7d26bd3b6abe584e7fe6cb67a07c281d.jpg', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '1', '/slider_images/9569de20ca1d815efcdfedc83c2e3e60.jpg', '230', '0', '1', 5, '0', '2020-12-07 13:57:20'),
(8, 'New Smartphone', 'some descr', '/images/051339b5fce18a3803999aac86175152.jpg', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '1', '/slider_images/051339b5fce18a3803999aac86175152.jpg', '250', '0', '0', 2, '1', '2020-12-07 01:53:24'),
(9, 'Smartphone', 'Lorem Ipsum', '/images/6688d7400e296a237f29638234a30747.jpg', 1, 'Black, White', 'LCD', '8K', '128GB', '4GB', '1', '/slider_images/99cb56aca8a0df78615aae9635bac407.jpg', '300', '0', '0', 4, '1', '2020-12-07 02:05:49'),
(12, 'Iphone', 'Descr...', '/images/a61111126bc23091195c9c4498c6ec30.webp', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '0', NULL, '250', '0', '1', 3, '1', '2020-12-07 13:51:21'),
(15, 'Honor New', 'Some descr for Honor and ...', '/images/6524016be96a3292ef9c14c432af00bb.jpg', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '0', NULL, '230', '0', '1', 0, '1', '2020-12-07 13:58:00'),
(16, 'Smartphone Name', 'Lorem ipsum', '/images/16489b64a03557edc4853dc352fd37c1.png', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '0', NULL, '300', '0', '1', 0, '1', '2020-12-07 14:39:45'),
(17, 'Smartphone Name', 'Lorem ipsum', '/images/71553078b02e73680f2842df7c6d722a.jpg', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '0', NULL, '180', '0', '0', 1, '1', '2020-12-07 14:40:05'),
(18, 'New Smartphone Name', 'Lorem ipsum Dolor ....', '/images/6d67e367be3223a077f1b080a3787427.jpg', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '0', NULL, '160', '0', '0', 0, '1', '2020-12-07 14:40:22'),
(19, 'New Smartphone', 'Lorem ipsum Dolor and...', '/images/d8885b0d44a795e24109d5915040e577.jpg', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '0', NULL, '210', '10', '0', 5, '1', '2020-12-07 14:40:55'),
(20, 'New Iphone', 'Lorem ipsum Dolor and...', '/images/2e33ea9cc5c147e07968bf13aeec8113.jpg', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '0', NULL, '310', '0', '0', 4, '1', '2020-12-07 14:41:21'),
(21, 'AAA', 'AAA', '/images/d5f1ce916fba7cad1761a5594da52624.jpg', 1, 'Black, White', 'LCD', '4K', '64GB', '4GB', '0', NULL, '250', '0', '0', 5, '1', '2020-12-07 23:32:10'),
(22, 'BBB', 'BBB', '/images/33866aa3c517e3b7cd2409a74eb2b50c.jpg', 1, 'Black, White', 'LCD', '4K', '128GB', '4GB', '0', NULL, '215', '0', '1', 8, '1', '2020-12-07 23:47:34'),
(23, 'CCC', 'CCC', '/images/199d96eee6db6dc22e80a89c53517ae2.jpg', 1, 'Black, White', 'LCD', '4K', '128GB', '4GB', '0', NULL, '215', '0', '0', 0, '1', '2020-12-07 23:48:48'),
(25, 'New Smartphone', 'Some descr for the new smartphone', '/images/b87fcbe1dd9107b54826ac831a167aa4.jpg', 1, 'Black, White, Green, Blue', 'LCD', '8K', '64GB', '4GB', '0', NULL, '260', '25', '1', 11, '1', '2020-12-25 21:45:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `personal_image` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `personal_image`, `email`, `password`, `status`) VALUES
(4, 'Sargis', 'Grigoryan', '/user_images/b89a8c5d769b034c498668628133bcd2.jpg', 'sargis.web@gmail.com', '$2y$10$R6D/bJxqWL4NC7q56d4cMu/PTHdrzmsg6QpifGMEgkrqM1/BSPlOu', '0'),
(5, 'John', 'Snow', '/user_images/9cf8205572cf282936aad1c4181b0115.jpg', 'saq.grigoryan158@gmail.com', '$2y$10$0cuzBcgowdfEP.x43OWaZeJkkE7WVxT6sNrZBW/IJZP5EDv4R/4dO', '0'),
(6, 'Grig', 'Grigoryan', '/user_images/b1a6f616442909959a3be850c5c50352.jpg', 'grig.grigoryan158@gmail.com', '$2y$10$Vh92YzYXtvupYvbakqtUF.GxiLuv7w0bNqAa/mnrEw.kZfxn58Hii', '0');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
